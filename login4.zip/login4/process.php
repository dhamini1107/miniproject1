<?php 

define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME', 'login');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

if(isset($_POST['userid'])){
    
   
    
  $ret=mysqli_query($con,"SELECT * FROM users WHERE userid='".$_POST['userid']."' and passid='".$_POST['passid']."'");
	$num=mysqli_num_rows($ret);
    echo $num;
    if($num==1){
        echo " You Have Successfully Logged in";
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}
?>