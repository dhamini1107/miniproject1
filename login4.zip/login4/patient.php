<html>
<head>
<title>Frames</title>
</head>
<body>
<iframe src="logo.php" style="height:100px;width:1345px" scrolling="no" ></iframe>

<iframe src="contentp.php" style="height: 420px;width:1345px"></iframe>

<iframe src="footer.php" style="height:66px;width:1345px" scrolling="no"></iframe>
</body>
</html>




