<!DOCTYPE html>
<head>
<title>Notification page</title>
<link rel="stylesheet" type="text/css" href="noti.css">
</head>
<body align="center"  >
<div class= "form">
 <h3>Student Id:</h3>
 <input type="text" placeholder="Enter Student-id" name="idnumber" ><br><br>
<a href="patientd.php"><input type="submit" value="Submit" name="Submit"><br> 
</div>
<div class= "form1">
<a href="pathist.php"><h1>Add details</h1></a>
</div>
</body>
</html>

