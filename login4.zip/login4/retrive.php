<!DOCTYPE html>
<head>
    <title> search</title>
    <style>
    body{
        background-image: url(med.jpg);
    }
    table,th,td{
        border:2px solid black;
        width:1100px;
        background-color:lightblue;
    }
    .btn{
        width:20%;
        height:5%;
        font-size:22px;
        padding:0px;
    }
    .container1{
    width:1150px;
	height:460px;
	background:rgba(0,40,40,0.5);
	color:black;
	top:50%;
	margin-left:-500px;
	position:absolute;
	transform:translate(50%,-50%);
	padding:20px 30px;
    }
    .a{
        color: lightblue;
    }
    .btn1{
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}
.btn2{
    float:right;
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}
</style>
</head>
<body>
<div class="container">
  
  <a href='index.php'> <button class="btn1" ><img src="1.png" alt="Snow" height=25px width=25px> Home</button></a>
  <a href='adminlo.php'><button class="btn2" >GOBACK</button></a> </div>
 </div>
    <div class="container1">
        <form action="" method="POST">
            <input type="text" name="id" class="btn"placeholder="Enter patient_ID"/>
            <input type="submit" name="search" class="btn"value="SEARCH"/>
            
        </form>
        <table>
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th> batch</th>
                    <th>branch</th>
                    <th>id</th>
               </tr> <br>
               <?php
               $connection = mysqli_connect("localhost","root","") ;
               $db=mysqli_select_db($connection,'login1');
               if(isset($_POST['search']))
               {
                   $id = $_POST['id'];
                   $query = "SELECT * FROM patient where id='$id'";

                   $query_run = mysqli_query($connection,$query);
                   while($row = mysqli_fetch_array($query_run))
                   {
                       ?>
                       <tr>
                           <td> <?php echo $row['name']; ?> </td>
                           <td> <?php echo $row['email']; ?> </td>
                           <td> <?php echo $row['batch']; ?> </td>
                           <td> <?php echo $row['branch']; ?> </td>
                           <td> <?php echo $row['id']; ?> </td>
                        </tr>
                        <?php

                      
                        
                   }
               } 
               ?>  
    </div>    
</table><br><br>
<table>
                <tr>
                    <th>id</th>
                    <th>disease</th>
                    <th> medicine</th>
                    <th>timing</th>
                    <th>date</th>
               </tr> <br>
               <?php
               $connection = mysqli_connect("localhost","root","") ;
               $db=mysqli_select_db($connection,'login1');
               if(isset($_POST['search']))
               {
                   $id = $_POST['id'];
                   $query = "SELECT * FROM medication where id='$id'";

                   $query_run = mysqli_query($connection,$query);
                   while($row = mysqli_fetch_array($query_run))
                   {
                       ?>
                       <tr>
                           <td> <?php echo $row['id']; ?> </td>
                           <td> <?php echo $row['disease']; ?> </td>
                           <td> <?php echo $row['medicine']; ?> </td>
                           <td> <?php echo $row['timing']; ?> </td>
                           <td> <?php echo $row['date']; ?> </td>
                        </tr>
                        <?php

                      
                        
                   }
               } 
               ?>  
    </div>    
</table><br><br>
</body>

</html>
