<!DOCTYPE html>
<html>
<head>
<style>
    table,th ,td{
        border: 1px solid black;
    }
</style>
<title>content</title>
</head>
<body>
<h2>DOCTOR DETAILS</h2>
<table>
<tr><td>Name</td>
    <td></td>
</tr>
 <tr><td>Email id</td>
    <td></td>
</tr>
</tr>
 <tr><td>Specialization</td>
    <td></td>
</tr>
</tr>
 <tr><td>Address</td>
    <td></td>
</tr>
</tr>
 <tr><td>Contact</td>
    <td></td>
</tr>
</table>
</body>
</html>

