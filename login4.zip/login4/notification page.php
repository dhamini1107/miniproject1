<!DOCTYPE html>
<head>
<title>Notification page</title>
</head>
<body align="center"  >
<font size="4"> Student Id: <input type="text" size=7 name="Idnumber" > <br>
	<br><a href="contentp.php"><input type="submit" value="Submit" name="Submit" >	<br> 
</font>

</body>
</html>

