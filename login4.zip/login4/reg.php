<?php
$set=mysqli_connect("localhost","root","","login1");
//include("setting.php");
$name=$_POST['name'];
$email=$_POST['email'];
$batch=$_POST['batch'];
$branch=$_POST['branch'];
$id=$_POST['id'];
$password=md5($_POST['pass']);
if($name==NULL || $email==NULL || $batch==NULL || $branch==NULL || $id==NULL || $_POST['pass']==NULL)
{
	//
}
else
{
	$sql=mysqli_query($set,"INSERT INTO patient (id,name,branch,batch,password,email) VALUES('$id','$name','$branch','$batch','$password','$email')");
	if($sql)
	{
		echo '<script type="text/javascript"> alert("Registration Successful") </script>';
	}
	else
	{
		echo '<script type="text/javascript"> alert("User already exists") </script>';
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registration</title>
<link href="reg.css" rel="stylesheet" type="text/css" />
<style>
.btn {
	top:0px;
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 12px;
  font-size: 20px;
  cursor: pointer;
  height:70px ;
  width:100px;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}

	</style>
</head>

<body>
<div class="container">
  
  <a href='index.php'> <button class="btn" ><img src="1.png" alt="Snow" height=px width=25px> Home</button></a>
 </div>
<div class="signbox">
<h1>Patient Registration</h1>
<br />
<br />
<form method="post" action="">
<table border="0" cellpadding="4" cellspacing="4" class="table">
<tr><td colspan="2" align="center" class="msg"><?php echo $msg;?></td></tr>
<tr><td class="labels">Name : </td><td><input type="text" name="name" class="fields" placeholder="Enter Full name" required="required" size="25" /></td></tr>
<tr><td class="labels">Email ID : </td><td><input type="email" name="email" class="fields" placeholder="Enter Email ID" required="required" size="25" /></td></tr>
<tr><td class="labels">Batch: </td>
<td>
<select name="batch" class="fields" required>
<option value="" disabled="disabled" selected="selected">- - Select batch - -</option>
<option value="O16">O16</option>
<option value="O17">O17</option>
<option value="O18">O18</option>
<option value="O19">O19</option>
<option value="O20">O20</option>
<option value="O21">O21</option>

</select>
</td></tr>

<tr><td class="labels">Branch : </td>
<td>
<select name="branch" class="fields" required>
<option value="" disabled="disabled" selected="selected">- - Select Branch - -</option>
<option value="Computer Engineering">Computer Engineering</option>
<option value="Electronics Engineering">Electronics Engineering</option>
<option value="Mechanical Engineering">Mechanical Engineering</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Information Technology">Information Technology</option>
</select>
</td></tr>
<tr><td class="labels">Student ID : </td><td><input type="text" name="id" class="fields" placeholder="Enter Student ID" required="required" size="25" /></td></tr>
<tr><td class="labels">Password : </td><td><input type="password" name="pass" class="fields" placeholder="Enter Password" required="required" size="25" /></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Register" class="fields" /></td></tr>
</table>
</form><br />
<br />
<a href="plog.php" class="link">Go Back</a>
<br />
<br />

</div>
</div>
</body>
</html>
