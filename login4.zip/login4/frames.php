<html>
<head>
<title>Frames</title>
</head>
<body>
<iframe src="logo.php" style="height:100px;width:1355px" scrolling="no" ></iframe>
<iframe src="retrive.php" style="height:475px;width:1355px"></iframe>

<iframe src="footer.html" style="height:55px;width:1355px" scrolling="no"></iframe>
</body>
</html>




