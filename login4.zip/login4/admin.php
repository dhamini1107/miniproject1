
<!DOCTYPE html>
<head>
<title>Frames</title>
</head>
<body>
<iframe src="logo.php" style="height:100px;width:1339px" scrolling="no" ></iframe>
<iframe src="retrive.php" style="height:430px;width:1342px"></iframe>
<iframe src="footer.php" style="height:55px;width:1339px" scrolling="no"></iframe>
</body>
</html>




