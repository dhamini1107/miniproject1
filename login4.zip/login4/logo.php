<html>
<head>
<title>logo</title>
</head>
<body bgcolor="darkblue" text="white" >
<img align="left" src=logo.jpeg height=75 width =75>
<h1 align="right" >Infirmary superintendence</h1>
<h4 >Rajiv Gandhi Institute of knowledge and technologies</h4>
</body>
</html

