<?php
$set=mysqli_connect("localhost","root","","login1");
//include("setting.php");
$id=$_POST['id'];
$disease=$_POST['disease'];
$medicine=$_POST['medicine'];
$timing=$_POST['timing'];
$date=$_POST['date'];

if($id==NULL || $disease==NULL || $medicine==NULL || $timing==NULL || $date==NULL)
{
	//
}
else
{
	$sql=mysqli_query($set,"INSERT INTO medication (id,disease,medicine,timing,date) VALUES('$id','$disease','$medicine','$timing','$date')");
	if($sql)
	{
		$msg="Successfully updated";
	}
	else
	{
		$msg="not updated";
	}
}
?>


<!DOCTYPE html>
<head>
<title>Registration</title>
<style>
	body{
		background-image:url('med.jpg');
	}
.btn {
	float:right;
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 12px;
  font-size: 20px;
  cursor: pointer;
  height:70px ;
  width:100px;
}
.signbox{
    width: 500px;
    position: absolute;
    background:rgba(0,0,0,0.3);
    top: 50%;
    left: 70%;
    transform: translate(-50%,-50%);
    color: black;
  }

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}
.link{
  	color: rgb(223, 223, 235);
  	padding:10px 180px;
  	text-decoration:none;
  	}

	</style>
</head>

<body>
<div class="container">
  
  <a href='index.php'> <button class="btn" ><img src="1.png" alt="Snow" height=px width=25px> Home</button></a>
 </div>
<div class="signbox">
<h1>Patient Medication</h1>
<br />
<br />

<form method="post" action="">
<table border="0" cellpadding="4" cellspacing="4" class="table">
<tr><td colspan="2" align="center" class="msg"><?php echo $msg;?></td></tr>
<tr><td class="labels">id : </td><td><input type="text" name="id" class="fields"  required="required" size="25" /></td></tr>
<tr><td class="labels">disease : </td><td><input type="text" name="disease" class="fields"  required="required"  size="25" /></td></tr>
<tr><td class="labels">medicine : </td><td><input type="text" name="medicine" class="fields"  required="required" size="25" /></td></tr>
<tr><td class="labels">timing: </td><td><input type="text" name="timing" class="fields"  required="required" size="25" /></td></tr>
<tr><td class="labels">date: </td><td><input type="date" name="date" class="fields"  required="required" size="25" /></td></tr>
<td>
<tr><td colspan="2" align="center"><input type="submit" value="Register" class="fields" /></td></tr>
</td></tr>


</table>
</form><br />
<br />
<a href="contentp.php" class="link"><h1>Go Back</h1></a>

</div>
</body>
</html>
