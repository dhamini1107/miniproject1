<html>
<head>
<title>FOOTER PAGE</title>
</head>
<body bgcolor="#3498DB">
<hr>
<footer align="center" style="bold">
	&copy;Rajiv Gandhi Institute of Knowledge and technologies
	 <br> Ongole
        
 
</footer>
</div>
</body>
</html>
