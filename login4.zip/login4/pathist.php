<?php
$set=mysqli_connect("localhost","root","","login1");
//include("setting.php");
$id=$_POST['id'];
$disease=$_POST['disease'];
$medicine=$_POST['medicine'];
$timing=$_POST['timing'];
if($id==NULL || $disease==NULL || $medicine==NULL || $timing==NULL)
{
	//
}
else
{
	$sql=mysqli_query($set,"INSERT INTO medication (id,disease,medicine,timing)VALUES('$id','$disease','$medicine','$timing'");
	if($sql)
	{
		$msg="Successfully saved";
	}
	else
	{
		$msg="Already info has been saved";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<style>
body{
    background-color: skyblue;
}
h1 {
  color: black;
  text-align: center;
}

p{
  font-family: verdana;
  font-size: 20px;
}
form{
	top:0px;
	left:0px;
	bottom:0px;
	right:0px;
	padding:50px 30px;
}
</style>
</head>
<body>
<h1>PATIENT HISTORY</h1>
<p colspan="2" align="center" class="msg"><?php echo $msg;?></p>
<p>
<div class="form">
<form id="frm1" action="">
 <h4 align="center">
  Patient Id: <input type="text" name="id"><br><br>
  Disease: <input type="text" name="disease"><br><br>
  Medicine:<input type="text" name="medicine"><br><br>
  Timing:<input type="text" name="timing"><br><br>
</form>

<br>
	
  <input type="button" onclick="myFunction()" value="Submit"><br> </br>
	<a href="contentp.php">GoBack</a>
</form></p></h6>
<script>
function myFunction() {
  document.getElementById("frm1").submit();
}
</script>

</body>
</html>

