<!DOCTYPE html>
<head>
    <title> search</title>
    <style>
    body{
        background-image:url('doct1.jpg');
    }
    table,th,td{
        border:2px solid black;
        width:1100px;
        background-color:lightblue;
    }
    .btn{
        width:20%;
        height:5%;
        font-size:22px;
        padding:0px;
    }
    .container{
    width:1150px;
	height:460px;
	background:rgba(0,0,0,0.3);
	color:black;
	top:50%;
	margin-left:-500px;
	position:absolute;
	transform:translate(50%,-50%);
	padding:20px 30px;
	
    }
    .btn1{
        background-color: DodgerBlue;
        float:right;
  border: none;
  color: white;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
    
    }
    .b a{
	font-size:15px;
	color:#fff;
}
.b a:hover{
	color:#39dc79;
}
</style>
</head>
<body>
<a href='index.php'> <button  class="btn1" ><img src="1.png" alt="Snow" height=25px width=25px> Home</button></a>
   </div>
    <div class="container">
        <form action="" method="POST">
            <input type="text" name="username" class="btn"placeholder="Enter doc username"/>
            <input type="submit" name="search" class="btn"value="SEARCH BY ID"/>
        </form>
        <table>
                <tr>
                    <th>name</th>
                    <th>qualification</th>
                    <th>email</th>
                    <th> contact</th>
                    <th>experience</th>
                    <th>username</th>
               </tr> <br>
               <?php
               $connection = mysqli_connect("localhost","root","") ;
               $db=mysqli_select_db($connection,'login1');
               if(isset($_POST['search']))
               {
                   $username = $_POST['username'];
                   $query = "SELECT * FROM doctor1 where username='$username'";

                   $query_run = mysqli_query($connection,$query);
                   while($row = mysqli_fetch_array($query_run))
                   {
                       ?>
                       <tr>
                           <td> <?php echo $row['name']; ?> </td>
                           <td> <?php echo $row['qualification']; ?> </td>
                           <td> <?php echo $row['email']; ?> </td>
                           <td> <?php echo $row['contact']; ?> </td>
                           <td> <?php echo $row['experience']; ?> </td>
                           <td> <?php echo $row['username']; ?> </td>
                        </tr>
                        <?php

                      
                        
                   }
               } 
               ?>  
    </div>    
</table>
<div class="b">
<a href="retrive1.php"><h1>Go back</h1></a>
            </div>
</body>

</html>
